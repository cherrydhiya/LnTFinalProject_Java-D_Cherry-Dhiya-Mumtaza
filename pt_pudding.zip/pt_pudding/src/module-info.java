/**
 * 
 */
/**
 * 
 */
module pt_pudding {
	requires java.desktop;
	requires java.sql;
}
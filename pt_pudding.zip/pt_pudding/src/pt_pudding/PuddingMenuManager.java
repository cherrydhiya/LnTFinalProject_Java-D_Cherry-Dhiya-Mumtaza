package pt_pudding;

import javax.swing.*;
import java.awt.*;

public class PuddingMenuManager extends JFrame {
    public PuddingMenuManager() {
        super("Pudding Menu Management System");
        initializeUI();
    }

    private void initializeUI() {
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(300, 200);
        setLayout(new GridLayout(4, 1, 10, 10));

        JButton btnCreate = new JButton("Create Menu");
        JButton btnView = new JButton("View Menu");
        JButton btnUpdate = new JButton("Update Menu");
        JButton btnDelete = new JButton("Delete Menu");

        btnCreate.addActionListener(e -> new Create(this));
        btnView.addActionListener(e -> new View(this));
        btnUpdate.addActionListener(e -> new Update(this));
        btnDelete.addActionListener(e -> new Delete(this));

        add(btnCreate);
        add(btnView);
        add(btnUpdate);
        add(btnDelete);

        setVisible(true);
    }

    public static void main(String[] args) {
        new PuddingMenuManager();
    }
}


package pt_pudding;
import javax.swing.*;
import java.awt.*;
import java.sql.*;

public class View extends JDialog {
    private JTextArea textArea;

    public View(JFrame parent) {
        super(parent, "View Puddings", true);
        setSize(400, 300);
        setLayout(new BorderLayout());

        textArea = new JTextArea();
        textArea.setEditable(false);
        add(new JScrollPane(textArea), BorderLayout.CENTER);

        loadPuddingData();
        setVisible(true);
    }

    private void loadPuddingData() {
        Connection conn = null;
        Statement stmt = null;
        ResultSet rs = null;
        try {
            conn = DatabaseConnection.getConnection();
            String sql = "SELECT * FROM PuddingMenu";
            stmt = conn.createStatement();
            rs = stmt.executeQuery(sql);

            StringBuilder puddingData = new StringBuilder();
            while (rs.next()) {
                puddingData.append("ID: ").append(rs.getString("PuddingID")).append(", ");
                puddingData.append("Name: ").append(rs.getString("PuddingName")).append(", ");
                puddingData.append("Price: Rp. ").append(rs.getDouble("PuddingPrice")).append(", ");
                puddingData.append("Stock: ").append(rs.getInt("PuddingStock")).append("\n");
            }
            if (textArea != null) {
                textArea.setText(puddingData.toString());
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Error loading pudding data: " + ex.getMessage(), "Database Error", JOptionPane.ERROR_MESSAGE);
        } finally {
            try {
                if (rs != null) rs.close();
                if (stmt != null) stmt.close();
                if (conn != null) conn.close();
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        }
    }

}


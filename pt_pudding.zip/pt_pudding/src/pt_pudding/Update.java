package pt_pudding;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;

public class Update extends JDialog {
    private JTextField txtPuddingID, txtPuddingName, txtPuddingPrice, txtPuddingStock;
    private JButton btnUpdate;

    public Update(JFrame parent) {
        super(parent, "Update Pudding", true);
        setSize(400, 250);
        setLayout(new GridLayout(5, 2, 5, 5));

        txtPuddingID = new JTextField(10);
        txtPuddingName = new JTextField(10);
        txtPuddingPrice = new JTextField(10);
        txtPuddingStock = new JTextField(10);
        btnUpdate = new JButton("Update");

        add(new JLabel("Pudding ID:"));
        add(txtPuddingID);
        add(new JLabel("New Pudding Name:"));
        add(txtPuddingName);
        add(new JLabel("New Pudding Price:"));
        add(txtPuddingPrice);
        add(new JLabel("New Pudding Stock:"));
        add(txtPuddingStock);
        add(new JLabel());
        add(btnUpdate);

        btnUpdate.addActionListener(this::updatePudding);
        setVisible(true);
    }

    private void updatePudding(ActionEvent e) {
        // JDBC code to update a pudding
    }
}

package pt_pudding;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;

public class Create extends JDialog {
    private JTextField txtPuddingID, txtPuddingName, txtPuddingPrice, txtPuddingStock;
    private JButton btnCreate;

    public Create(JFrame parent) {
        super(parent, "Create Pudding", true);
        setLayout(new GridLayout(5, 2, 5, 5));
        setSize(400, 250);

        txtPuddingID = new JTextField(10);
        txtPuddingName = new JTextField(10);
        txtPuddingPrice = new JTextField(10);
        txtPuddingStock = new JTextField(10);
        btnCreate = new JButton("Create");

        add(new JLabel("Pudding ID:"));
        add(txtPuddingID);
        add(new JLabel("Pudding Name:"));
        add(txtPuddingName);
        add(new JLabel("Pudding Price:"));
        add(txtPuddingPrice);
        add(new JLabel("Pudding Stock:"));
        add(txtPuddingStock);
        add(new JLabel());
        add(btnCreate);

        btnCreate.addActionListener(this::createPudding);
        setVisible(true);
    }

    private void createPudding(ActionEvent e) {
        String puddingID = txtPuddingID.getText();
        String puddingName = txtPuddingName.getText();
        double puddingPrice = Double.parseDouble(txtPuddingPrice.getText());
        int puddingStock = Integer.parseInt(txtPuddingStock.getText());

        Connection conn = null;
        PreparedStatement pstmt = null;
        try {
            conn = DatabaseConnection.getConnection();  // Ensure you have a DatabaseConnection class that can provide a Connection
            String sql = "INSERT INTO PuddingMenu (PuddingID, PuddingName, PuddingPrice, PuddingStock) VALUES (?, ?, ?, ?)";
            pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, puddingID);
            pstmt.setString(2, puddingName);
            pstmt.setDouble(3, puddingPrice);
            pstmt.setInt(4, puddingStock);

            int rowsInserted = pstmt.executeUpdate();
            if (rowsInserted > 0) {
                JOptionPane.showMessageDialog(this, "A new pudding item was successfully inserted!");
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Error inserting pudding: " + ex.getMessage(), "Database Error", JOptionPane.ERROR_MESSAGE);
        } finally {
            try {
                if (pstmt != null) pstmt.close();
                if (conn != null) conn.close();
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        }
    }

}


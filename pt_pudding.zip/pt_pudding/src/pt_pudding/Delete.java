package pt_pudding;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;

public class Delete extends JDialog {
    private JTextField txtPuddingID;
    private JButton btnDelete;

    public Delete (JFrame parent) {
        super(parent, "Delete Pudding", true);
        setSize(300, 150);
        setLayout(new GridLayout(2, 2, 5, 5));

        txtPuddingID = new JTextField(10);
        btnDelete = new JButton("Delete");

        add(new JLabel("Pudding ID:"));
        add(txtPuddingID);
        add(new JLabel());
        add(btnDelete);

        btnDelete.addActionListener(this::deletePudding);
        setVisible(true);
    }

    private void deletePudding(ActionEvent e) {
        String puddingID = txtPuddingID.getText();

        Connection conn = null;
        PreparedStatement pstmt = null;
        try {
            conn = DatabaseConnection.getConnection();
            String sql = "DELETE FROM PuddingMenu WHERE PuddingID = ?";
            pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, puddingID);

            int rowsDeleted = pstmt.executeUpdate();
            if (rowsDeleted > 0) {
                JOptionPane.showMessageDialog(this, "Pudding item deleted successfully!");
            } else {
                JOptionPane.showMessageDialog(this, "No Pudding found with ID: " + puddingID, "Deletion Error", JOptionPane.ERROR_MESSAGE);
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Error deleting pudding: " + ex.getMessage(), "Database Error", JOptionPane.ERROR_MESSAGE);
        } finally {
            try {
                if (pstmt != null) pstmt.close();
                if (conn != null) conn.close();
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        }
    }

}
